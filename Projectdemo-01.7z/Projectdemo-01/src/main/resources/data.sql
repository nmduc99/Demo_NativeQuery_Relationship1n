insert into user(username,password) values('nmduc','123');
insert into user(username,password) values('nmduc1','123');
insert into user(username,password) values('nmduc2','123');

insert into address(city, USER_ID) values('Tuy Hoa',1);
insert into address(city, USER_ID) values('Tuy Hoa1',2);
insert into address(city, USER_ID) values('Tuy Hoa2',3);