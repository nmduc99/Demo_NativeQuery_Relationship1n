insert into customer(name,phonenumber) values ('Nguyễn Minh Đức','0386475579');
insert into customer(name,phonenumber) values ('ABC1','3232323232');
insert into customer(name,phonenumber) values ('ABC3','3232323232');
insert into customer(name,phonenumber) values ('ABC4','3232323232');

