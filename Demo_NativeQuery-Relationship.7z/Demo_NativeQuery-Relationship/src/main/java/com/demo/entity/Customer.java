package com.demo.entity;

import javax.persistence.*;


@Entity
@Table(name="Customer")
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	private String name;
	private String phonenumber;
	@ManyToOne
	@JoinColumn(name= "address_id")
	private Address address;
	
	
	
	public Customer() {
		super();
	}
	public Customer(String name, String phonenumber, Address address) {
		
		this.name = name;
		this.phonenumber = phonenumber;
		this.address = address;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", phonenumber=" + phonenumber + ", address=" + address + "]";
	}
	
	
}
