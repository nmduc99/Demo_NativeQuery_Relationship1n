package com.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


import com.demo.repository.CustomerRepository;

@SpringBootApplication
public class DemoNativeQueryRelationshipApplication implements CommandLineRunner{

	public static void main(String[] args) {
	 
		SpringApplication.run(DemoNativeQueryRelationshipApplication.class, args);
		 		
	}
	@Autowired
	CustomerRepository  customRepo;
	

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		customRepo.getAll().forEach( item -> {
			System.out.println(item); });
		
		System.out.println("_____________--_______");
		
		customRepo.findByNameLike("%A%").forEach(item ->{
			System.out.println(item);
		});
	}
	
		
}
