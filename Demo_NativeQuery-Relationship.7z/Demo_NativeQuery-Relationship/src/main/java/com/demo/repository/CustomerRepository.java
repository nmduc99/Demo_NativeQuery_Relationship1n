package com.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.demo.entity.Customer;

@Repository
public interface CustomerRepository extends CrudRepository<Customer, Long> {
	
	
	@Query(value = "SELECT * FROM CUSTOMER ",  nativeQuery = true)
	public List<Customer> getAll();
	
	  @Query(value= "SELECT e FROM Customer e WHERE e.name like ?1")
	 public List<Customer> findByNameLike(String name);
}
